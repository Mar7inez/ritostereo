# 🚀 Configuración para Hostinger - PHP 8.3+

## ⚙️ Configuración de PHP

### 1. Cambiar versión de PHP
1. **Panel de Hostinger** → **Avanzado** → **Selector de versión de PHP**
2. **Seleccionar PHP 8.3** o superior
3. **Aplicar cambios**

### 2. Configurar php.ini
1. **Panel de Hostinger** → **Avanzado** → **Editor de archivos**
2. **Crear archivo `php.ini`** en la raíz del sitio
3. **Copiar contenido** del archivo `php.ini` incluido en este proyecto

### 3. Verificar configuración
```bash
# Crear archivo test-php.php
<?php
phpinfo();
?>
```

## 📧 Configuración de Email

### 1. Configurar Gmail App Password
1. **Gmail** → **Configuración** → **Seguridad**
2. **Verificación en 2 pasos** (debe estar activada)
3. **Contraseñas de aplicación** → **Generar nueva**
4. **Copiar la contraseña** generada

### 2. Actualizar .env
```env
MAIL_PASS=tu_app_password_aqui
APP_URL=https://tu-dominio.com
```

## 🔧 Verificaciones Post-Instalación

### 1. Verificar PHP 8.3+
- Visitar: `https://tu-dominio.com/test-php.php`
- Confirmar que muestra PHP 8.3 o superior

### 2. Verificar formulario de contacto
- Llenar formulario de contacto
- Verificar que llegue el email a `ritostereo@gmail.com`

### 3. Verificar logs
- Revisar `storage/logs/contact-messages.txt`
- Revisar `storage/logs/php-errors.log`

## 🚨 Solución de Problemas

### Error: "PHP version too old"
- Cambiar a PHP 8.3+ en el panel de Hostinger

### Error: "Class not found"
- Verificar que `vendor/autoload.php` esté presente
- Ejecutar `composer install` si es necesario

### Error: "Permission denied"
- Cambiar permisos de `storage/` a 755
- Cambiar permisos de `storage/logs/` a 777

### Error: "Email not sending"
- Verificar configuración de Gmail App Password
- Revisar logs de PHP para errores específicos

## 📊 Optimizaciones PHP 8.3+

### Características utilizadas:
- **Type declarations**: `string`, `mixed`, `int`
- **Return types**: Especificados en todas las funciones
- **Null coalescing**: `??` para valores por defecto
- **JIT compilation**: Habilitado en php.ini
- **OPcache**: Optimizado para mejor rendimiento

### Rendimiento esperado:
- **Carga inicial**: 20-30% más rápida
- **Memoria**: Uso optimizado con OPcache
- **Seguridad**: Mejorada con type declarations
